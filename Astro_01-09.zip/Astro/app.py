import streamlit as st
import pandas as pd
import json
from datetime import date, time, datetime, timedelta

from astro_core.chart import build_natal_chart
from astro_core.transits import (
    get_transit_calendar,
    find_transit_events,
    find_transit_periods,
    calculate_transit_positions,
    find_transits_on_date,
)
from astro_core.ephemeris import SWISSEPH_AVAILABLE
from astro_core.constants import (
    DEFAULT_TRANSIT_PLANETS,
    ASPECT_DEFINITIONS,
    get_planet_name_ru,
    get_sign_name_ru,
    get_aspect_name_ru,
    get_object_type_name_ru,
    get_direction_name_ru,
)
from astro_core.profiles import (
    save_profile,
    load_profile,
    list_profiles,
    delete_profile,
)
from astro_core.progressions import (
    calculate_secondary_progressions,
    calculate_solar_arc_progressions,
    find_progression_aspects,
)

from astro_core.chart_svg import render_natal_chart_svg, render_transit_chart_svg
from astro_core.chart_interactive import render_interactive_chart, render_interactive_transit_chart
from astro_core.cities import load_cities, search_cities, get_city_by_name, get_city_display_name
from astro_core.timezone_service import get_utc_offset_hours, get_timezone_info
from astro_core.chart import build_natal_chart
from datetime import datetime as dt_datetime
from astro_core.time_service import datetime_to_jd
import streamlit.components.v1 as components

# ============================================================
# Настройка страницы
# ============================================================

st.set_page_config(
    page_title="Astro Processor",
    page_icon="🌟",
    layout="wide",
)

st.title("🌟 Astro Processor")
st.markdown("Локальный модульный астрологический процессор")

# Проверка Swiss Ephemeris
if not SWISSEPH_AVAILABLE:
    st.error(
        "Swiss Ephemeris is not installed. "
        "Please install it with: `py -3.11 -m pip install pyswisseph`"
    )
    st.stop()


# ============================================================
# Боковая панель: ПРОФИЛИ
# ============================================================

st.sidebar.header("👤 Профили")

# Читаем список профилей при каждом запуске скрипта
profiles = list_profiles()
profile_names = [p.get("name", "Без имени") for p in profiles]

with st.sidebar:
    if profile_names:
        selected_profile_name = st.selectbox(
            "Выбрать профиль",
            options=profile_names,
            index=None,
            placeholder="— выберите профиль —",
        )
    else:
        st.info("Профилей пока нет. Заполните форму и сохраните.")
        selected_profile_name = None

    # Пометка, если сейчас редактируется профиль
    editing_profile = st.session_state.get("editing_profile")
    if editing_profile:
        st.info(f"✏️ Редактируется: {editing_profile}")

    col_load, col_edit = st.columns(2)

    with col_load:
        load_profile_button = st.button(
            "📂 Загрузить",
            disabled=(selected_profile_name is None),
            use_container_width=True,
        )

    with col_edit:
        edit_profile_button = st.button(
            "✏️ Редактировать",
            disabled=(selected_profile_name is None),
            use_container_width=True,
        )

    confirm_delete = st.checkbox(
        "Подтвердить удаление",
        value=False,
        key="confirm_delete",
    )
    delete_profile_button = st.button(
        "🗑️ Удалить профиль",
        disabled=(selected_profile_name is None or not confirm_delete),
        use_container_width=True,
    )

    # --------------------------------------------------------
    # Обработчик ЗАГРУЗКИ профиля
    # --------------------------------------------------------
    if load_profile_button and selected_profile_name:
        try:
            profile = load_profile(selected_profile_name)

            st.session_state["input_name"] = profile.get("name", "")

            if "date" in profile:
                st.session_state["input_birth_date"] = datetime.strptime(
                    profile["date"], "%Y-%m-%d"
                ).date()

            if "time" in profile:
                st.session_state["input_birth_time"] = datetime.strptime(
                    profile["time"], "%H:%M"
                ).time()

            # При загрузке используем ручной режим, чтобы показать сохранённые координаты
            st.session_state["location_mode"] = "Ввести координаты вручную"
            st.session_state["input_latitude"] = float(profile.get("latitude", 0.0))
            st.session_state["input_longitude"] = float(profile.get("longitude", 0.0))
            st.session_state["input_utc_offset"] = float(profile.get("utc_offset_hours", 0.0))

            # Сохраняем город и часовой пояс из профиля (если были), чтобы не потерять при пересохранении
            st.session_state["selected_city_name"] = profile.get("city", "")
            st.session_state["selected_timezone"] = profile.get("timezone", "")

            # Загрузка — это не редактирование
            st.session_state.pop("editing_profile", None)

            st.sidebar.success(f"Профиль «{selected_profile_name}» загружен.")
            st.rerun()
        except FileNotFoundError:
            st.sidebar.error(f"Профиль «{selected_profile_name}» не найден.")
        except Exception as error:
            st.sidebar.error(f"Ошибка загрузки профиля: {error}")

    # --------------------------------------------------------
    # Обработчик РЕДАКТИРОВАНИЯ профиля
    # --------------------------------------------------------
    if edit_profile_button and selected_profile_name:
        try:
            profile = load_profile(selected_profile_name)

            st.session_state["input_name"] = profile.get("name", "")

            if "date" in profile:
                st.session_state["input_birth_date"] = datetime.strptime(
                    profile["date"], "%Y-%m-%d"
                ).date()

            if "time" in profile:
                st.session_state["input_birth_time"] = datetime.strptime(
                    profile["time"], "%H:%M"
                ).time()

            st.session_state["location_mode"] = "Ввести координаты вручную"
            st.session_state["input_latitude"] = float(profile.get("latitude", 0.0))
            st.session_state["input_longitude"] = float(profile.get("longitude", 0.0))
            st.session_state["input_utc_offset"] = float(profile.get("utc_offset_hours", 0.0))

            st.session_state["selected_city_name"] = profile.get("city", "")
            st.session_state["selected_timezone"] = profile.get("timezone", "")

            # Запоминаем, что редактируем именно этот профиль
            st.session_state["editing_profile"] = selected_profile_name

            st.sidebar.info(
                f"Редактирование профиля «{selected_profile_name}». "
                f"Измените данные и нажмите «Сохранить изменения»."
            )
            st.rerun()
        except FileNotFoundError:
            st.sidebar.error(f"Профиль «{selected_profile_name}» не найден.")
        except Exception as error:
            st.sidebar.error(f"Ошибка загрузки профиля: {error}")

    # --------------------------------------------------------
    # Обработчик УДАЛЕНИЯ профиля
    # --------------------------------------------------------
    if delete_profile_button and selected_profile_name:
        try:
            delete_profile(selected_profile_name)
            st.session_state["confirm_delete"] = False

            # Если редактировали этот профиль — выходим из режима редактирования
            if st.session_state.get("editing_profile") == selected_profile_name:
                st.session_state.pop("editing_profile", None)

            st.sidebar.success(f"Профиль «{selected_profile_name}» удалён.")
            st.rerun()
        except Exception as error:
            st.sidebar.error(f"Ошибка удаления профиля: {error}")

    st.divider()


# ============================================================
# Боковая панель: ДАННЫЕ РОЖДЕНИЯ
# ============================================================

st.sidebar.header("📅 Данные рождения")

with st.sidebar:
    name = st.text_input(
        "Имя",
        value="Иван",
        key="input_name",
    )

    birth_date = st.date_input(
        "Дата рождения",
        value=date(1990, 5, 15),
        min_value=date(1900, 1, 1),
        max_value=date(2100, 12, 31),
        key="input_birth_date",
    )

    birth_time = st.time_input(
        "Время рождения",
        value=time(14, 30),
        key="input_birth_time",
    )

    st.divider()

    # Выбор способа ввода местоположения
    location_mode = st.radio(
        "Местоположение",
        ["Выбрать город из списка", "Ввести координаты вручную"],
        index=0,
        key="location_mode",
    )

    if location_mode == "Выбрать город из списка":
        # Поиск города
        city_query = st.text_input(
            "Поиск города",
            value="",
            key="city_query",
            help="Введите название города на русском или английском языке",
        )

        # Получаем список городов по запросу
        if city_query.strip():
            found_cities = search_cities(city_query, limit=10)
        else:
            found_cities = load_cities()[:10]

        if found_cities:
            # Формируем список для выбора
            city_options = [get_city_display_name(c) for c in found_cities]

            selected_city_display = st.selectbox(
                "Выберите город",
                options=city_options,
                index=0,
                key="selected_city",
            )

            # Находим выбранный город
            selected_city = None
            for city in found_cities:
                if get_city_display_name(city) == selected_city_display:
                    selected_city = city
                    break

            if selected_city:
                # Отображаем информацию о выбранном городе
                st.caption(
                    f"📍 {selected_city['name']}, {selected_city['country']}\n"
                    f"Широта: {selected_city['latitude']:.4f}, "
                    f"Долгота: {selected_city['longitude']:.4f}\n"
                    f"Часовой пояс: {selected_city['timezone']}"
                )

                # Используем координаты города
                latitude = selected_city["latitude"]
                longitude = selected_city["longitude"]

                # Определяем часовой пояс и смещение от Гринвича автоматически
                timezone_name = selected_city.get("timezone", "")

                if timezone_name:
                    try:
                        # Создаём datetime для даты рождения
                        birth_dt_for_tz = dt_datetime.combine(birth_date, birth_time)
                        tz_info = get_timezone_info(timezone_name, birth_dt_for_tz)
                        utc_offset = tz_info["utc_offset"]

                        # Отображаем информацию о часовом поясе
                        st.caption(
                            f"🕐 Часовой пояс: {timezone_name}\n"
                            f"Смещение от Гринвича: {tz_info['utc_offset_str']}\n"
                            f"Летнее время: {'Да' if tz_info['is_dst'] else 'Нет'}"
                        )
                    except ValueError as e:
                        st.warning(f"Не удалось определить часовой пояс: {e}")
                        utc_offset = 0.0
                else:
                    utc_offset = 0.0
            else:
                latitude = 0.0
                longitude = 0.0
                utc_offset = 0.0
        else:
            st.warning("Город не найден. Попробуйте другой запрос или введите координаты вручную.")
            latitude = 0.0
            longitude = 0.0
            utc_offset = 0.0

    else:
        # Ручной ввод координат
        latitude = st.number_input(
            "Широта",
            min_value=-90.0,
            max_value=90.0,
            value=55.7558,
            format="%.4f",
            key="input_latitude",
        )

        longitude = st.number_input(
            "Долгота",
            min_value=-180.0,
            max_value=180.0,
            value=37.6173,
            format="%.4f",
            key="input_longitude",
        )

        utc_offset = st.number_input(
            "Смещение UTC (часы)",
            min_value=-12.0,
            max_value=14.0,
            value=3.0,
            format="%.1f",
            key="input_utc_offset",
        )

    # --------------------------------------------------------
    # Сохранение профиля (с учётом режима редактирования)
    # --------------------------------------------------------
    editing_profile = st.session_state.get("editing_profile")

    if editing_profile:
        save_label = "💾 Сохранить изменения"
        col_save, col_cancel = st.columns([2, 1])
        with col_save:
            save_profile_button = st.button(
                save_label, type="primary", use_container_width=True
            )
        with col_cancel:
            cancel_edit_button = st.button("Отмена", use_container_width=True)

        if cancel_edit_button:
            st.session_state.pop("editing_profile", None)
            st.rerun()
    else:
        save_label = "💾 Сохранить как профиль"
        save_profile_button = st.button(save_label, use_container_width=True)

    if save_profile_button:
        if not name.strip():
            st.sidebar.warning("Введите имя перед сохранением профиля.")
        else:
            new_name = name.strip()

            profile_data = {
                "name": new_name,
                "date": birth_date.strftime("%Y-%m-%d"),
                "time": birth_time.strftime("%H:%M"),
                "latitude": latitude,
                "longitude": longitude,
                "utc_offset_hours": utc_offset,
                "city": st.session_state.get("selected_city_name", ""),
                "timezone": st.session_state.get("selected_timezone", ""),
            }

            try:
                save_profile(profile_data)

                # Если при редактировании изменили имя — переименовываем профиль
                if editing_profile and new_name != editing_profile:
                    delete_profile(editing_profile)
                    st.session_state.pop("editing_profile", None)
                    st.sidebar.success(
                        f"Профиль переименован: «{editing_profile}» → «{new_name}»."
                    )
                elif editing_profile:
                    st.session_state.pop("editing_profile", None)
                    st.sidebar.success(f"Изменения профиля «{new_name}» сохранены.")
                else:
                    st.sidebar.success(f"Профиль «{new_name}» сохранён.")

                st.rerun()
            except Exception as error:
                st.sidebar.error(f"Ошибка сохранения профиля: {error}")

    st.divider()

    st.subheader("Настройки")

    house_system = st.selectbox(
        "Система домов",
        ["placidus", "koch", "equal", "whole_sign", "porphyry"],
        index=0,
    )

    # Тип зодиака
    zodiac_type_display = st.radio(
        "Тип зодиака",
        ["Тропический", "Сидерический"],
        index=0,
        help="Тропический — стандарт западной астрологии. Сидерический — привязка к реальным созвездиям (ведическая астрология).",
    )

    # Преобразуем отображаемое значение в машинное
    zodiac_type = "tropical" if zodiac_type_display == "Тропический" else "sidereal"

    # Система аянамши (показывается только для сидерического зодиака)
    ayanamsha = "lahiri"  # значение по умолчанию
    if zodiac_type == "sidereal":
        ayanamsha_display = st.selectbox(
            "Система аянамши",
            ["Лахири", "Раман", "Кришнамурти", "Фаган-Брэдли"],
            index=0,
            help="Аянамша — величина сдвига между тропическим и сидерическим зодиаками. Лахири — стандарт в ведической астрологии.",
        )
        # Преобразуем отображаемое значение в машинное
        ayanamsha_map = {
            "Лахири": "lahiri",
            "Раман": "raman",
            "Кришнамурти": "krishnamurti",
            "Фаган-Брэдли": "fagan_brady",
        }
        ayanamsha = ayanamsha_map[ayanamsha_display]

    include_chiron = st.checkbox("Хирон", value=True)
    include_nodes = st.checkbox("Лунные узлы", value=True)
    include_fortune = st.checkbox("Part of Fortune", value=True)
    include_angles = st.checkbox("ASC/MC", value=True)

    st.divider()

    ephe_path = st.text_input(
        "Путь к эфемеридам",
        value="ephe",
    )

    calculate_button = st.button(
        "Рассчитать карту",
        type="primary",
    )

    # --------------------------------------------------------
    # Секция транзитов (появляется после расчёта карты)
    # --------------------------------------------------------
    if "chart_result" in st.session_state:
        st.divider()

        with st.expander("Транзиты", expanded=False):
            transit_mode = st.radio(
                "Режим",
                [
                    "Быстрый (по дням)",
                    "Точный (с временем аспектов)",
                    "Периоды активности",
                ],
                index=0,
            )

            # Фильтр по планетам
            planet_options = list(DEFAULT_TRANSIT_PLANETS)
            selected_planets = st.multiselect(
                "Транзитные планеты (пусто = все)",
                options=planet_options,
                format_func=get_planet_name_ru,
                default=[],
            )

            # Фильтр по аспектам
            aspect_options = [a["name"] for a in ASPECT_DEFINITIONS]
            selected_aspects = st.multiselect(
                "Аспекты (пусто = все)",
                options=aspect_options,
                format_func=get_aspect_name_ru,
                default=[],
            )

            # Период
            transit_date_option = st.radio(
                "Тип периода",
                ["Одна дата", "Диапазон дат"],
                index=1,
            )

            if transit_date_option == "Одна дата":
                transit_single_date = st.date_input(
                    "Дата транзитов",
                    value=date.today(),
                    min_value=date(1900, 1, 1),
                    max_value=date(2100, 12, 31),
                )
            else:
                transit_start_date = st.date_input(
                    "Дата начала",
                    value=date.today(),
                    min_value=date(1900, 1, 1),
                    max_value=date(2100, 12, 31),
                )
                transit_end_date = st.date_input(
                    "Дата конца",
                    value=date.today() + timedelta(days=7),
                    min_value=date(1900, 1, 1),
                    max_value=date(2100, 12, 31),
                )

            # Подсказки для режимов
            if transit_mode == "Быстрый (по дням)":
                st.caption("Быстрый режим подходит для больших периодов.")
            elif transit_mode == "Точный (с временем аспектов)":
                st.caption(
                    "Точный режим медленнее. "
                    "Рекомендуется для периодов до 7–14 дней."
                )
            else:
                st.caption(
                    "Периоды активности показывают вход в орб, пик и выход из орба. "
                    "Рекомендуется для периодов до 7–14 дней."
                )

            calculate_transits_button = st.button(
                "Рассчитать транзиты",
                type="primary",
            )


# ============================================================
# Обработка нажатия кнопки расчёта карты
# ============================================================

if calculate_button:
    birth = {
        "name": name,
        "date": birth_date.strftime("%Y-%m-%d"),
        "time": birth_time.strftime("%H:%M"),
        "latitude": latitude,
        "longitude": longitude,
        "utc_offset_hours": utc_offset,
    }

    settings = {
        "house_system": house_system,
        "include_chiron": include_chiron,
        "include_nodes": include_nodes,
        "include_part_of_fortune": include_fortune,
        "include_angles": include_angles,
        "ephe_path": ephe_path if ephe_path else None,
        "zodiac": zodiac_type,
        "ayanamsha": ayanamsha,
    }

    try:
        result = build_natal_chart(birth, settings)
        st.session_state["chart_result"] = result
        st.session_state["birth"] = birth
        st.session_state["settings"] = settings
        # Очищаем предыдущие транзиты при новом расчёте карты
        st.session_state.pop("transit_result", None)
        st.session_state.pop("transit_mode_used", None)
        st.session_state.pop("transit_period", None)
        st.rerun()
    except Exception as error:
        st.error(f"Ошибка расчёта карты: {error}")


# ============================================================
# Обработка нажатия кнопки расчёта транзитов
# ============================================================

try:
    transits_requested = calculate_transits_button
except NameError:
    transits_requested = False

if transits_requested and "chart_result" in st.session_state:
    natal_objects = st.session_state["chart_result"]["objects"]

    # Определяем период
    if transit_date_option == "Одна дата":
        start_date = transit_single_date.strftime("%Y-%m-%d")
        end_date = transit_single_date.strftime("%Y-%m-%d")
    else:
        start_date = transit_start_date.strftime("%Y-%m-%d")
        end_date = transit_end_date.strftime("%Y-%m-%d")

    # Настройки транзитов
    transit_settings = dict(st.session_state["settings"])

    # Параметры фильтрации
    filter_planets = selected_planets if selected_planets else None
    filter_aspects = selected_aspects if selected_aspects else None

    with st.spinner("Расчёт транзитов... Пожалуйста, подождите."):
        try:
            if "Периоды активности" in transit_mode:
                periods = find_transit_periods(
                    natal_objects,
                    start_date,
                    end_date,
                    transit_settings,
                    filter_planets=filter_planets,
                    filter_aspects=filter_aspects,
                )
                st.session_state["transit_result"] = periods
                st.session_state["transit_mode_used"] = "periods"
                st.session_state["transit_period"] = (start_date, end_date)

            elif "Точный" in transit_mode:
                events = find_transit_events(
                    natal_objects,
                    start_date,
                    end_date,
                    transit_settings,
                    filter_planets=filter_planets,
                    filter_aspects=filter_aspects,
                )
                st.session_state["transit_result"] = events
                st.session_state["transit_mode_used"] = "precise"
                st.session_state["transit_period"] = (start_date, end_date)

            else:
                calendar = get_transit_calendar(
                    natal_objects,
                    start_date,
                    end_date,
                    transit_settings,
                    filter_planets=filter_planets,
                    filter_aspects=filter_aspects,
                )
                st.session_state["transit_result"] = calendar
                st.session_state["transit_mode_used"] = "calendar"
                st.session_state["transit_period"] = (start_date, end_date)

        except Exception as error:
            st.error(f"Ошибка расчёта транзитов: {error}")


# ============================================================
# Отображение результата натальной карты
# ============================================================

if "chart_result" in st.session_state:
    result = st.session_state["chart_result"]

    st.divider()

    # Заголовок карты
    chart_name = result["birth"].get("name", "Chart")
    st.subheader(f"Натальная карта: {chart_name}")

    # Основные данные
    col1, col2, col3, col4 = st.columns(4)
    with col1:
        st.metric("Дата", result["birth"]["date"])
    with col2:
        st.metric("Время", result["birth"]["time"])
    with col3:
        st.metric("UTC", result["utc_datetime"])
    with col4:
        st.metric("Julian Day", result["julian_day"])

    # Предупреждения
    if result.get("warnings"):
        with st.expander("Предупреждения", expanded=False):
            for warning in result["warnings"]:
                st.warning(warning)

    # Вкладки натальной карты
    tab_chart, tab_objects, tab_houses, tab_aspects, tab_progressions, tab_json = st.tabs(
        ["🌌 Карта", "Объекты", "Дома", "Аспекты", "🔄 Прогрессии", "JSON"]
    )

        # --------------------------------------------------------
    # Вкладка: Карта
    # --------------------------------------------------------
    with tab_chart:
        st.subheader("Графическая карта")

        # Переключатель типа карты
        chart_type = st.radio(
            "Тип карты",
            ["Натальная карта", "Транзитная карта"],
            index=0,
            key="chart_type",
        )

        # Элементы управления в две колонки
        ctrl_col1, ctrl_col2 = st.columns(2)

        with ctrl_col1:
            show_words = st.checkbox(
                "Показать названия словами",
                value=False,
                help="Если включено, рядом с символами будут показаны названия словами",
            )
            show_aspects = st.checkbox(
                "Показать аспекты",
                value=True,
                help="Если включено, на карте будут показаны линии аспектов",
            )

        with ctrl_col2:
            chart_size = st.slider(
                "Размер карты",
                min_value=600,
                max_value=1200,
                value=800,
                step=100,
                help="Размер карты в пикселях",
            )

        # Определяем режим подписей
        label_mode = "both" if show_words else "symbols"

        if chart_type == "Натальная карта":
            # ----------------------------------------------------
            # Натальная карта
            # ----------------------------------------------------
            interactive_html = render_interactive_chart(
                result,
                size=chart_size,
                show_aspects=show_aspects,
                label_mode=label_mode,
            )

            components.html(interactive_html, height=chart_size + 60, scrolling=True)

            st.caption(
                "💡 Управление картой: "
                "колесо мыши — зум, "
                "зажать левую кнопку и двигать — перетаскивание, "
                "кнопка «🔄 Сбросить вид» — возврат к исходному состоянию."
            )

            # Кнопка скачивания (статичный SVG)
            static_svg = render_natal_chart_svg(
                result,
                size=chart_size,
                show_aspects=show_aspects,
                label_mode=label_mode,
            )

            st.download_button(
                label="📥 Скачать карту (SVG)",
                data=static_svg,
                file_name="natal_chart.svg",
                mime="image/svg+xml",
                help="Скачать натальную карту в векторном формате SVG",
            )

        else:
            # ----------------------------------------------------
            # Транзитная карта
            # ----------------------------------------------------
            st.markdown("#### Дата транзитов")

            transit_date_for_chart = st.date_input(
                "Дата транзитов",
                value=date.today(),
                min_value=date(1900, 1, 1),
                max_value=date(2100, 12, 31),
                key="transit_date_for_chart",
            )

            st.markdown("#### Город транзита")

            # Выбор местоположения транзита
            transit_location_mode = st.radio(
                "Местоположение транзита",
                ["Без привязки к городу", "Выбрать город транзита"],
                index=0,
                key="transit_location_mode",
            )

            transit_city = None

            if transit_location_mode == "Выбрать город транзита":
                transit_city_query = st.text_input(
                    "Поиск города транзита",
                    value="",
                    key="transit_city_query",
                    help="Введите название города на русском или английском языке",
                )

                # Получаем список городов по запросу
                if transit_city_query.strip():
                    found_transit_cities = search_cities(transit_city_query, limit=10)
                else:
                    found_transit_cities = load_cities()[:10]

                if found_transit_cities:
                    transit_city_options = [get_city_display_name(c) for c in found_transit_cities]

                    selected_transit_city_display = st.selectbox(
                        "Выберите город транзита",
                        options=transit_city_options,
                        index=0,
                        key="selected_transit_city",
                    )

                    # Находим выбранный город
                    for city in found_transit_cities:
                        if get_city_display_name(city) == selected_transit_city_display:
                            transit_city = city
                            break

                    if transit_city:
                        st.caption(
                            f"📍 {transit_city['name']}, {transit_city['country']}\n"
                            f"Часовой пояс: {transit_city['timezone']}"
                        )
                else:
                    st.warning("Город не найден. Попробуйте другой запрос.")

            # Рассчитываем дома и углы транзита, если выбран город
            transit_houses = None
            transit_additional_points = None

            if transit_city is not None:
                try:
                    transit_tz_name = transit_city.get("timezone", "")
                    if transit_tz_name:
                        transit_dt_for_tz = dt_datetime.combine(transit_date_for_chart, time(12, 0))
                        transit_utc_offset_hours = get_utc_offset_hours(transit_tz_name, transit_dt_for_tz)
                    else:
                        transit_utc_offset_hours = 0.0

                    # Получаем путь к эфемеридам из настроек натальной карты
                    natal_settings_for_ephe = st.session_state.get("settings", {})
                    transit_ephe_path = natal_settings_for_ephe.get("ephe_path", "ephe")

                    # Строим карту транзита для города (для получения домов и углов)
                    transit_chart_birth = {
                        "name": "Транзит",
                        "date": transit_date_for_chart.strftime("%Y-%m-%d"),
                        "time": "12:00",
                        "latitude": transit_city["latitude"],
                        "longitude": transit_city["longitude"],
                        "utc_offset_hours": transit_utc_offset_hours,
                    }
                    transit_chart_settings = {
                        "include_chiron": False,
                        "include_nodes": False,
                        "include_part_of_fortune": False,
                        "include_angles": True,
                        "ephe_path": transit_ephe_path,
                    }
                    transit_chart_result = build_natal_chart(transit_chart_birth, transit_chart_settings)
                    transit_houses = transit_chart_result.get("houses", [])
                    transit_additional_points = transit_chart_result.get("additional_points", [])
                except Exception as e:
                    st.warning(f"Не удалось рассчитать дома транзита для города: {e}")


            # Рассчитываем позиции транзитных планет на выбранную дату
            try:
                transit_dt = datetime.combine(transit_date_for_chart, time(12, 0))
                transit_utc_dt = transit_dt - timedelta(hours=utc_offset)
                transit_jd = datetime_to_jd(transit_utc_dt)

                                # Получаем транзитные планеты
                transit_settings = {
                    "include_chiron": False,
                    "include_nodes": False,
                }
                transit_planets_list, _ = calculate_transit_positions(transit_jd, transit_settings)

                # Применяем фильтр по планетам (из боковой панели, секция "Транзиты")
                if selected_planets:
                    transit_planets_list = [
                        p for p in transit_planets_list
                        if p["name"] in selected_planets
                    ]

                # Применяем фильтр по аспектам (из боковой панели, секция "Транзиты")
                transit_chart_settings = dict(result.get("settings", {}))
                if selected_aspects:
                    transit_chart_settings["enabled_aspects"] = list(selected_aspects)

                # Получаем транзитные аспекты
                natal_objects = result.get("objects", [])
                transit_aspects_list = find_transits_on_date(
                    natal_objects,
                    transit_planets_list,
                    transit_chart_settings,
                )

                # Отображаем транзитную карту
                transit_svg = render_transit_chart_svg(
                    result,
                    transit_planets_list,
                    transit_aspects_list,
                    size=chart_size,
                    label_mode=label_mode,
                    show_aspects=show_aspects,
                    transit_houses=transit_houses,
                    transit_additional_points=transit_additional_points,
                )

                # Отображаем интерактивную транзитную карту
                interactive_transit_html = render_interactive_transit_chart(
                    result,
                    transit_planets_list,
                    transit_aspects_list,
                    size=chart_size,
                    label_mode=label_mode,
                    show_aspects=show_aspects,
                    transit_houses=transit_houses,
                    transit_additional_points=transit_additional_points,
                )
                components.html(interactive_transit_html, height=chart_size + 60, scrolling=True)

                transit_city_note = ""
                if transit_city is not None:
                    transit_city_note = f" Город транзита: {transit_city['name']}. Зелёные линии — дома транзита, Тр. ASC / Тр. MC — углы транзита."

                st.caption(
                    f"📅 Транзиты на {transit_date_for_chart.strftime('%d.%m.%Y')}. "
                    f"Синий — натальные планеты, зелёный — транзитные планеты. "
                    f"Пунктирные линии — транзитные аспекты.{transit_city_note}\n"
                    f"💡 Управление картой: колесо мыши — зум, "
                    f"зажать левую кнопку и двигать — перетаскивание, "
                    f"кнопка «🔄 Сбросить вид» — возврат к исходному состоянию."
                )

                # Кнопка скачивания
                st.download_button(
                    label="📥 Скачать транзитную карту (SVG)",
                    data=transit_svg,
                    file_name=f"transit_chart_{transit_date_for_chart.strftime('%Y%m%d')}.svg",
                    mime="image/svg+xml",
                    help="Скачать транзитную карту в векторном формате SVG",
                )

            except Exception as e:
                st.error(f"Ошибка расчёта транзитной карты: {e}")


    # --------------------------------------------------------
    # Вкладка: Объекты
    # --------------------------------------------------------
    with tab_objects:
        objects_data = []

        for p in result.get("planets", []):
            objects_data.append({
                "Тип": get_object_type_name_ru(p.get("type", "planet")),
                "Название": get_planet_name_ru(p["name"]),
                "Знак": get_sign_name_ru(p["sign"]),
                "Градус в знаке": round(p["degree_in_sign"], 2),
                "Долгота": round(p["longitude"], 2),
                "Дом": p.get("house", "-"),
                "Ретроград": "Да" if p.get("retrograde") else "Нет",
            })

        for p in result.get("additional_points", []):
            objects_data.append({
                "Тип": get_object_type_name_ru(p.get("type", "point")),
                "Название": get_planet_name_ru(p["name"]),
                "Знак": get_sign_name_ru(p["sign"]),
                "Градус в знаке": round(p["degree_in_sign"], 2),
                "Долгота": round(p["longitude"], 2),
                "Дом": p.get("house", "-"),
                "Ретроград": "-",
            })

        if objects_data:
            df_objects = pd.DataFrame(objects_data)
            st.dataframe(df_objects, use_container_width=True, hide_index=True)
        else:
            st.info("Нет данных об объектах.")

    # --------------------------------------------------------
    # Вкладка: Дома
    # --------------------------------------------------------
    with tab_houses:
        houses_data = []

        for h in result.get("houses", []):
            houses_data.append({
                "Дом": h["house"],
                "Знак": get_sign_name_ru(h["sign"]),
                "Градус в знаке": round(h["degree_in_sign"], 2),
                "Долгота": round(h["longitude"], 2),
            })

        if houses_data:
            df_houses = pd.DataFrame(houses_data)
            st.dataframe(df_houses, use_container_width=True, hide_index=True)
        else:
            st.info("Нет данных о домах.")

    # --------------------------------------------------------
    # Вкладка: Аспекты
    # --------------------------------------------------------
    with tab_aspects:
        aspects_data = []

        for a in result.get("aspects", []):
            aspects_data.append({
                "Точка A": get_planet_name_ru(a["point_a"]),
                "Точка B": get_planet_name_ru(a["point_b"]),
                "Аспект": get_aspect_name_ru(a["aspect"]),
                "Угол": round(a["angle"], 2),
                "Орб": round(a["orb"], 2),
                "Макс. орб": a["max_orb"],
                "Сила": round(a["strength"], 2),
            })

        if aspects_data:
            df_aspects = pd.DataFrame(aspects_data)
            st.dataframe(df_aspects, use_container_width=True, hide_index=True)
        else:
            st.info("Нет данных об аспектах.")

    # --------------------------------------------------------
    # Вкладка: Прогрессии
    # --------------------------------------------------------
    with tab_progressions:
        st.subheader("Прогрессии")

        st.markdown(
            "Прогрессии — это астрологическая техника, которая «развивает» натальную карту во времени. "
            "Вторичные прогрессии используют принцип: 1 день после рождения = 1 год жизни."
        )

        # Элементы управления в две колонки
        prog_col1, prog_col2 = st.columns(2)

        with prog_col1:
            progression_date = st.date_input(
                "Дата прогрессии",
                value=date.today(),
                min_value=date(1900, 1, 1),
                max_value=date(2100, 12, 31),
                key="progression_date",
                help="Дата, на которую рассчитываются прогрессии",
            )

        with prog_col2:
            progression_type_display = st.radio(
                "Тип прогрессий",
                ["Вторичные (день за год)", "Солнечная дуга"],
                index=0,
                key="progression_type",
                help="Вторичные прогрессии: 1 день после рождения = 1 год жизни. "
                     "Солнечная дуга: все планеты продвигаются на то же расстояние, что и прогрессивное Солнце.",
            )

        # Кнопка расчёта прогрессий
        calculate_progressions_button = st.button(
            "Рассчитать прогрессии",
            type="primary",
            key="calculate_progressions_button",
        )

        if calculate_progressions_button:
            try:
                # Получаем данные рождения и настройки из сессии
                birth = st.session_state["birth"]
                settings = st.session_state["settings"]

                # Определяем тип прогрессий
                progression_type = "secondary" if "Вторичные" in progression_type_display else "solar_arc"

                # Рассчитываем прогрессии
                if progression_type == "secondary":
                    progression_result = calculate_secondary_progressions(
                        birth,
                        progression_date.strftime("%Y-%m-%d"),
                        settings,
                    )
                else:
                    progression_result = calculate_solar_arc_progressions(
                        birth,
                        progression_date.strftime("%Y-%m-%d"),
                        settings,
                    )

                # Сохраняем результат в сессию
                st.session_state["progression_result"] = progression_result
                st.session_state["progression_type_used"] = progression_type

            except Exception as e:
                st.error(f"Ошибка расчёта прогрессий: {e}")

        # Отображение результатов прогрессий
        if "progression_result" in st.session_state:
            progression_result = st.session_state["progression_result"]
            progression_type_used = st.session_state.get("progression_type_used", "secondary")

            st.divider()

            # Информация о прогрессиях
            col_info1, col_info2, col_info3 = st.columns(3)

            with col_info1:
                st.metric("Дата прогрессии", progression_result["progression_date"])

            with col_info2:
                st.metric("Возраст", f"{progression_result['age_years']} лет")

            with col_info3:
                if progression_type_used == "solar_arc":
                    st.metric("Солнечная дуга", f"{progression_result.get('solar_arc', 0):.2f}°")
                else:
                    st.metric("Тип", "Вторичные прогрессии")

            # Предупреждения
            if progression_result.get("warnings"):
                with st.expander("Предупреждения", expanded=False):
                    for warning in progression_result["warnings"]:
                        st.warning(warning)

            # Таблица прогрессивных планет
            st.markdown("#### Прогрессивные планеты")

            planets_data = []
            for p in progression_result.get("planets", []):
                planets_data.append({
                    "Планета": get_planet_name_ru(p["name"]),
                    "Знак": get_sign_name_ru(p["sign"]),
                    "Градус в знаке": round(p["degree_in_sign"], 2),
                    "Долгота": round(p["longitude"], 2),
                })

            if planets_data:
                df_planets = pd.DataFrame(planets_data)
                st.dataframe(df_planets, use_container_width=True, hide_index=True)
            else:
                st.info("Нет данных о прогрессивных планетах.")

            # Таблица дополнительных точек (для вторичных прогрессий)
            if progression_result.get("additional_points"):
                st.markdown("#### Прогрессивные точки (ASC, MC, Part of Fortune)")

                points_data = []
                for p in progression_result["additional_points"]:
                    points_data.append({
                        "Точка": get_planet_name_ru(p["name"]),
                        "Знак": get_sign_name_ru(p["sign"]),
                        "Градус в знаке": round(p["degree_in_sign"], 2),
                        "Долгота": round(p["longitude"], 2),
                    })

                if points_data:
                    df_points = pd.DataFrame(points_data)
                    st.dataframe(df_points, use_container_width=True, hide_index=True)

            # Аспекты прогрессий к натальным точкам
            st.markdown("#### Аспекты прогрессий к натальным точкам")

            try:
                birth = st.session_state["birth"]
                settings = st.session_state["settings"]
                natal_result = st.session_state["chart_result"]

                progression_aspects = find_progression_aspects(
                    natal_result["objects"],
                    progression_result["objects"],
                    settings,
                )

                if progression_aspects:
                    aspects_data = []
                    for a in progression_aspects:
                        aspects_data.append({
                            "Прогрессивная планета": get_planet_name_ru(a["progressed_planet"]),
                            "Аспект": get_aspect_name_ru(a["aspect"]),
                            "Натальная точка": get_planet_name_ru(a["natal_point"]),
                            "Орб": round(a["orb"], 2),
                            "Сила": round(a["strength"], 2),
                        })

                    df_aspects = pd.DataFrame(aspects_data)
                    st.dataframe(df_aspects, use_container_width=True, hide_index=True)
                else:
                    st.info("Аспекты прогрессий к натальным точкам не найдены.")

            except Exception as e:
                st.warning(f"Не удалось рассчитать аспекты прогрессий: {e}")

            # Кнопка скачивания результата
            json_str = json.dumps(progression_result, ensure_ascii=False, indent=2)
            st.download_button(
                label="📥 Скачать прогрессии (JSON)",
                data=json_str,
                file_name=f"progressions_{progression_result['progression_date']}.json",
                mime="application/json",
                help="Скачать результат расчёта прогрессий в формате JSON",
            )
        else:
            st.info(
                "Выберите дату прогрессии и тип прогрессий, затем нажмите «Рассчитать прогрессии»."
            )

    # --------------------------------------------------------
    # Вкладка: JSON
    # --------------------------------------------------------
    with tab_json:
        st.json(result)

    # ========================================================
    # Отображение транзитов
    # ========================================================
    if "transit_result" in st.session_state:
        st.divider()
        st.subheader("Транзиты")

        transit_mode_used = st.session_state.get("transit_mode_used", "calendar")
        transit_period = st.session_state.get("transit_period", ("", ""))
        transit_result = st.session_state["transit_result"]

        st.markdown(f"**Период:** {transit_period[0]} — {transit_period[1]}")

        # ----------------------------------------------------
        # Режим: Периоды активности
        # ----------------------------------------------------
        if transit_mode_used == "periods":
            st.markdown("**Режим:** Периоды активности (вход в орб → пик → выход из орба)")

            if transit_result:
                periods_data = []
                for period in transit_result:
                    start_dt = period.get("start_datetime", "")
                    exact_dt = period.get("exact_datetime", "")
                    end_dt = period.get("end_datetime", "")

                    if "T" in start_dt:
                        start_date_part, start_time_part = start_dt.split("T")
                    else:
                        start_date_part = start_dt
                        start_time_part = ""

                    if "T" in exact_dt:
                        exact_date_part, exact_time_part = exact_dt.split("T")
                    else:
                        exact_date_part = exact_dt
                        exact_time_part = ""

                    if "T" in end_dt:
                        end_date_part, end_time_part = end_dt.split("T")
                    else:
                        end_date_part = end_dt
                        end_time_part = ""

                    direction = period.get("direction", "direct")
                    direction_label = get_direction_name_ru(direction)

                    periods_data.append({
                        "Транзитная планета": get_planet_name_ru(period.get("transit_planet", "")),
                        "Аспект": get_aspect_name_ru(period.get("aspect", "")),
                        "Натальная точка": get_planet_name_ru(period.get("natal_point", "")),
                        "Направление": direction_label,
                        "Вход в орб": f"{start_date_part} {start_time_part}",
                        "Пик (точный)": f"{exact_date_part} {exact_time_part}",
                        "Выход из орба": f"{end_date_part} {end_time_part}",
                        "Орб": period.get("orb", 0),
                    })

                df_periods = pd.DataFrame(periods_data)
                st.dataframe(df_periods, use_container_width=True, hide_index=True)

                json_str = json.dumps(transit_result, ensure_ascii=False, indent=2)
                st.download_button(
                    label="Скачать периоды активности (JSON)",
                    data=json_str,
                    file_name="transit_periods.json",
                    mime="application/json",
                )
            else:
                st.info("Периоды активности не найдены за указанный период.")

        # ----------------------------------------------------
        # Режим: Точный (с временем аспектов)
        # ----------------------------------------------------
        elif transit_mode_used == "precise":
            st.markdown("**Режим:** Точный (с временем аспектов)")

            if transit_result:
                events_data = []
                for event in transit_result:
                    dt_str = event.get("exact_datetime", "")
                    if "T" in dt_str:
                        date_part, time_part = dt_str.split("T")
                    else:
                        date_part = dt_str
                        time_part = ""

                    direction = event.get("direction", "direct")
                    direction_label = get_direction_name_ru(direction)

                    events_data.append({
                        "Дата": date_part,
                        "Время": time_part,
                        "Направление": direction_label,
                        "Транзитная планета": get_planet_name_ru(event.get("transit_planet", "")),
                        "Аспект": get_aspect_name_ru(event.get("aspect", "")),
                        "Натальная точка": get_planet_name_ru(event.get("natal_point", "")),
                    })

                df_events = pd.DataFrame(events_data)
                st.dataframe(df_events, use_container_width=True, hide_index=True)

                json_str = json.dumps(transit_result, ensure_ascii=False, indent=2)
                st.download_button(
                    label="Скачать транзиты (JSON)",
                    data=json_str,
                    file_name="precise_transits.json",
                    mime="application/json",
                )
            else:
                st.info("Транзиты не найдены за указанный период.")

        # ----------------------------------------------------
        # Режим: Быстрый (по дням)
        # ----------------------------------------------------
        else:
            st.markdown("**Режим:** Быстрый (по дням)")

            if transit_result:
                calendar_data = []
                for entry in transit_result:
                    calendar_data.append({
                        "Дата": entry.get("date", ""),
                        "Транзитная планета": get_planet_name_ru(entry.get("transit_planet", "")),
                        "Аспект": get_aspect_name_ru(entry.get("aspect", "")),
                        "Натальная точка": get_planet_name_ru(entry.get("natal_point", "")),
                        "Орб": round(entry.get("orb", 0), 2),
                        "Сила": round(entry.get("strength", 0), 2),
                    })

                df_calendar = pd.DataFrame(calendar_data)
                st.dataframe(df_calendar, use_container_width=True, hide_index=True)

                json_str = json.dumps(transit_result, ensure_ascii=False, indent=2)
                st.download_button(
                    label="Скачать транзиты (JSON)",
                    data=json_str,
                    file_name="transit_calendar.json",
                    mime="application/json",
                )
            else:
                st.info("Транзиты не найдены за указанный период.")

else:
    st.info(
        "Введите данные рождения в боковой панели и нажмите «Рассчитать карту». "
        "Вы также можете загрузить сохранённый профиль из списка вверху."
    )