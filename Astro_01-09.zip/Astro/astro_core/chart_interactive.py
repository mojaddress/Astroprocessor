"""
Модуль интерактивного отображения карт.

Оборачивает SVG-карты в HTML с JavaScript для поддержки:
- зума колесом мыши;
- перетаскивания (панорамирования);
- сброса вида к исходному состоянию.

Поддерживает два типа карт:
- Натальная карта (один круг планет)
- Транзитная карта (два круга: натальные и транзитные планеты)

Интерактивность работает полностью в браузере, без обращения к серверу.
Это обеспечивает плавное управление без задержек.

Важно:
    Этот модуль используется для отображения карт в веб-интерфейсе.
    Для скачивания карт используется статичный SVG из модуля chart_svg.
"""

import uuid

from .chart_svg import render_natal_chart_svg, render_transit_chart_svg


# ============================================================
# JavaScript для интерактивности
# ============================================================

# Шаблон скрипта. Фигурные скобки экранированы как {{ и }}
# для корректной работы метода .format()
_INTERACTIVE_SCRIPT_TEMPLATE = """
<script>
document.addEventListener('DOMContentLoaded', function() {{
    var svg = document.getElementById('{svg_id}');
    if (!svg) {{
        console.error('SVG element not found: {svg_id}');
        return;
    }}

    console.log('Interactive chart initialized: {svg_id}');

    // Сохраняем исходный viewBox для кнопки сброса
    var initialViewBox = {{
        x: svg.viewBox.baseVal.x,
        y: svg.viewBox.baseVal.y,
        width: svg.viewBox.baseVal.width,
        height: svg.viewBox.baseVal.height
    }};

    // Текущий viewBox (изменяется при зуме и перетаскивании)
    var viewBox = {{
        x: initialViewBox.x,
        y: initialViewBox.y,
        width: initialViewBox.width,
        height: initialViewBox.height
    }};

    function updateViewBox() {{
        svg.setAttribute('viewBox',
            viewBox.x + ' ' + viewBox.y + ' ' + viewBox.width + ' ' + viewBox.height);
    }}

    // --------------------------------------------------------
    // Зум колесом мыши
    // --------------------------------------------------------
    svg.addEventListener('wheel', function(e) {{
        e.preventDefault();
        e.stopPropagation();

        // Определяем направление зума
        var scaleFactor = e.deltaY > 0 ? 1.1 : 0.9;

        // Получаем координаты мыши в системе координат SVG
        var rect = svg.getBoundingClientRect();
        var mouseX = (e.clientX - rect.left) / rect.width * viewBox.width + viewBox.x;
        var mouseY = (e.clientY - rect.top) / rect.height * viewBox.height + viewBox.y;

        // Вычисляем новый размер видимой области
        var newWidth = viewBox.width * scaleFactor;
        var newHeight = viewBox.height * scaleFactor;

        // Ограничиваем зум (нельзя приближать бесконечно)
        if (newWidth < 50 || newWidth > 5000) return;

        // Масштабируем относительно позиции мыши
        viewBox.x = mouseX - (mouseX - viewBox.x) * scaleFactor;
        viewBox.y = mouseY - (mouseY - viewBox.y) * scaleFactor;
        viewBox.width = newWidth;
        viewBox.height = newHeight;

        updateViewBox();
    }}, {{ passive: false }});

    // --------------------------------------------------------
    // Перетаскивание (панорамирование)
    // Используем Pointer Events для надёжной работы
    // --------------------------------------------------------
    var isDragging = false;
    var lastX = 0;
    var lastY = 0;

    svg.addEventListener('pointerdown', function(e) {{
        isDragging = true;
        lastX = e.clientX;
        lastY = e.clientY;
        svg.style.cursor = 'grabbing';
        svg.setPointerCapture(e.pointerId);
        e.preventDefault();
    }});

    svg.addEventListener('pointermove', function(e) {{
        if (!isDragging) return;

        var rect = svg.getBoundingClientRect();
        var dx = (e.clientX - lastX) / rect.width * viewBox.width;
        var dy = (e.clientY - lastY) / rect.height * viewBox.height;

        viewBox.x -= dx;
        viewBox.y -= dy;

        lastX = e.clientX;
        lastY = e.clientY;

        updateViewBox();
    }});

    svg.addEventListener('pointerup', function(e) {{
        isDragging = false;
        svg.style.cursor = 'grab';
        if (svg.hasPointerCapture(e.pointerId)) {{
            svg.releasePointerCapture(e.pointerId);
        }}
    }});

    svg.addEventListener('pointercancel', function(e) {{
        isDragging = false;
        svg.style.cursor = 'grab';
        if (svg.hasPointerCapture(e.pointerId)) {{
            svg.releasePointerCapture(e.pointerId);
        }}
    }});

    // --------------------------------------------------------
    // Кнопка сброса вида
    // --------------------------------------------------------
    var resetBtn = document.getElementById('{svg_id}_reset');
    if (resetBtn) {{
        resetBtn.addEventListener('click', function() {{
            viewBox.x = initialViewBox.x;
            viewBox.y = initialViewBox.y;
            viewBox.width = initialViewBox.width;
            viewBox.height = initialViewBox.height;
            updateViewBox();
        }});
    }} else {{
        console.error('Reset button not found: {svg_id}_reset');
    }}

    // Устанавливаем курсор при наведении
    svg.style.cursor = 'grab';
    svg.style.touchAction = 'none';
}});
</script>
"""


# ============================================================
# Вспомогательная функция обёртки
# ============================================================

def _make_interactive_html(svg_content):
    """
    Оборачивает SVG-контент в интерактивный HTML.

    Это общая функция, которая используется и для натальной,
    и для транзитной карты.

    Параметры:
        svg_content: SVG-строка (должна содержать один корневой элемент <svg>)

    Возвращает:
        HTML-строку с интерактивной картой
    """
    # Генерируем уникальный идентификатор для этой карты
    svg_id = f"chart_{uuid.uuid4().hex[:8]}"

    # Добавляем уникальный идентификатор к SVG
    svg_content = svg_content.replace('<svg ', f'<svg id="{svg_id}" ', 1)

    # Генерируем JavaScript для интерактивности
    script = _INTERACTIVE_SCRIPT_TEMPLATE.format(svg_id=svg_id)

    # Оборачиваем в HTML-контейнер с кнопкой сброса
    html = f"""
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <style>
        body {{
            margin: 0;
            padding: 0;
            overflow: hidden;
        }}
        .chart-container {{
            position: relative;
            display: inline-block;
        }}
        .reset-button {{
            position: absolute;
            top: 10px;
            right: 10px;
            z-index: 10;
            padding: 6px 12px;
            cursor: pointer;
            background-color: #f0f0f0;
            border: 1px solid #ccc;
            border-radius: 4px;
            font-size: 12px;
            font-family: Arial, sans-serif;
        }}
        .reset-button:hover {{
            background-color: #e0e0e0;
        }}
        svg {{
            display: block;
        }}
    </style>
</head>
<body>
    <div class="chart-container">
        <button id="{svg_id}_reset" class="reset-button">
            🔄 Сбросить вид
        </button>
        {svg_content}
    </div>
    {script}
</body>
</html>
"""

    return html


# ============================================================
# Публичные функции
# ============================================================

def render_interactive_chart(chart_data, size=800, show_aspects=True,
                             label_mode="symbols"):
    """
    Генерирует интерактивную натальную карту в формате HTML.

    Параметры:
        chart_data: словарь с данными карты (результат build_natal_chart)
        size: размер карты в пикселях
        show_aspects: отображать ли аспекты
        label_mode: режим подписей ("symbols", "words", "both")

    Возвращает:
        HTML-строку с интерактивной картой
    """
    svg_content = render_natal_chart_svg(
        chart_data,
        size=size,
        show_aspects=show_aspects,
        label_mode=label_mode,
    )

    return _make_interactive_html(svg_content)


def render_interactive_transit_chart(natal_chart, transit_planets, transit_aspects,
                                     size=800, label_mode="symbols", show_aspects=True,
                                     transit_houses=None, transit_additional_points=None):
    """
    Генерирует интерактивную транзитную карту в формате HTML.

    Параметры:
        natal_chart: словарь с данными натальной карты (результат build_natal_chart)
        transit_planets: список транзитных планет с долготами
        transit_aspects: список транзитных аспектов
        size: размер карты в пикселях
        label_mode: режим подписей ("symbols", "words", "both")
        show_aspects: отображать ли аспекты (натальные и транзитные)
        transit_houses: список домов транзитной карты (опционально)
        transit_additional_points: список углов транзитной карты (опционально)

    Возвращает:
        HTML-строку с интерактивной картой
    """
    svg_content = render_transit_chart_svg(
        natal_chart,
        transit_planets,
        transit_aspects,
        size=size,
        label_mode=label_mode,
        show_aspects=show_aspects,
        transit_houses=transit_houses,
        transit_additional_points=transit_additional_points,
    )

    return _make_interactive_html(svg_content)